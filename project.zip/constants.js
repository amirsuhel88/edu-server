export const DB_NAME = "edu";
