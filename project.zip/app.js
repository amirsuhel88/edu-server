// app.js
import express from "express";
import mongoose from "mongoose";
import { userModel } from "./models/userModel.js"; // Adjust the path as necessary

const app = express(); // Declare app

// Middleware to parse JSON
app.use(express.json());

// Example route using the userModel
app.get("/users", async (req, res) => {
  try {
    const users = await userModel.find();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/addUser", async (req, res) => {
  try {
    const newUser = new userModel({
      name: "Test User",
      email: "testuser@example.com",
      phone: "1234567890",
      password: "password123",
      role: "student",
    });
    await newUser.save();
    res.status(201).json({ message: "User created successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Export the app as default
export default app;
